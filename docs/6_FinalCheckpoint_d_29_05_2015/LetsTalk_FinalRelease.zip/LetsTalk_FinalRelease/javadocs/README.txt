In order to view the javadocs simply open in your browser the file "index.html" 
that is found in both Client_Javadoc and Server_Javadoc folders.

In the first you can see all the documentation on the source code of Client
and in the second all the documentation on source code of Server.