package se.bth.swatkats.letstalk.connection.encryption;

import java.io.Serializable;

import javax.crypto.Cipher;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;

import se.bth.swatkats.letstalk.Constants;

public class Encrypter {

	public static SealedObject encrypt(SecretKey key, Serializable object)
			throws Exception {

		// Create cipher
		Cipher cipher = Cipher.getInstance(Constants.transformation);
		cipher.init(Cipher.ENCRYPT_MODE, key);
		return new SealedObject(object, cipher);
	}

	public static Object decrypt(SecretKey key, SealedObject sealedObject)
			throws Exception {
		Cipher cipher = Cipher.getInstance(Constants.transformation);
		cipher.init(Cipher.DECRYPT_MODE, key);
		return sealedObject.getObject(cipher);
	}

}