package se.bth.swatkats.letstalk.file.download;

public class Main extends Thread{
	private String name;
	private String fileurl;
	   public Main(String name,String url)
	   {
		   this.name=name;
		   this.fileurl=url;
	   }
	   public void run(){
		  try {
			  filedownload c=new filedownload(fileurl,name);
			  user u = new user(c);
		      c.saveFile();
		  }catch(Exception e) {  
	            e.printStackTrace();  
	        }  
	   }
	   public static void main(String name,String url) throws Exception
	   {
	      new Main(name,url).start();
	   }


}
