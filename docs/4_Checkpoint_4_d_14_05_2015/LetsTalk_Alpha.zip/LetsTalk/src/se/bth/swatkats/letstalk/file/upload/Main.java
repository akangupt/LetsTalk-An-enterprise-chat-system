package se.bth.swatkats.letstalk.file.upload;

public class Main extends Thread{
	private String path;
	private int fileid;
	   public Main(String path,int fileid)
	   {
		   this.path=path;
		   this.fileid=fileid;
	   }
	   public void run(){
		  try {
			  fileupload c=new fileupload(path);
			  user u = new user(c);
		      c.sendFile(fileid);
		  }catch(Exception e) {  
	            e.printStackTrace();  
	        }  
	   }
	   public static void main(String path,int fileid) throws Exception
	   {
	      new Main(path,fileid).start();
	   }


}
