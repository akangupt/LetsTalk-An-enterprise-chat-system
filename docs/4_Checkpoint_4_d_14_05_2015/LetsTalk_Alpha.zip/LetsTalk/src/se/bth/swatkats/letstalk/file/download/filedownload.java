package se.bth.swatkats.letstalk.file.download;
import java.io.File; 
import java.io.FileOutputStream;  
import java.io.ObjectInputStream;  
import java.io.ObjectOutputStream;  
import java.net.Socket;
import java.util.Observable;
import java.util.Observer;
import java.util.ArrayList;


import se.bth.swatkats.letstalk.Constants;
public class filedownload extends Observable {
	private static final int BUFFER_SIZE = 4096; 
	private Socket socket;
	private FileOutputStream fos = null;
	private String fileurl;
	private long FILE_SIZE,DOWNLOADED=0;
	private ArrayList<Observer> users=new ArrayList<Observer>();
	public long getValue()
    {
       return (DOWNLOADED/FILE_SIZE)*100;
    }
    public void addObserver(Observer observer){
        users.add(observer);		
     }
    public void removeObserver(Observer observer){
        users.remove(observer);		
     }
	public filedownload(String fileurl,String filename) {  
		try {  
			    fos = new FileOutputStream(new File (filename));
			    this.fileurl=fileurl;
                socket = new Socket(Constants.HOST, 1995);    
        } catch (Exception e) {  
            e.printStackTrace();  
        }    
            }  

	  public void saveFile() throws Exception
	  {	  
	        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());  
	        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());   
	        byte [] buffer = new byte[BUFFER_SIZE];  
	  
	        // 1. Write file path.  
	        Object file ;  
	        oos.writeObject(fileurl);  
	   
	        FILE_SIZE=ois.readLong();
	  
	        // 2. Read file to the end.  
	        Integer bytesRead = new Integer(0);  
	  
	        do {  
	            file = ois.readObject();  
	  
	            if (!(file instanceof Integer)) {  
	                throwException("Number of bytes to be read not received");  
	            }  
	  
	            bytesRead = (Integer)file;  
	  
	            file = ois.readObject();  
	  
	            if (!(file instanceof byte[])) {  
	                throwException("No bytes received");  
	            }  
	  
	            buffer = (byte[])file;  
	  
	            // 3. Write data to output file.  
	            fos.write(buffer, 0, bytesRead.intValue()); 
	            this.DOWNLOADED=DOWNLOADED+bytesRead.longValue();
	            setChanged();
	            notifyObservers();
	            
	        } while (bytesRead.intValue() == BUFFER_SIZE);  
	          
	        System.out.println("File transfer success");  
	          
	        fos.close();  
	        ois.close();  
	        oos.close();  
	    }
  public static void throwException(String message) throws Exception {  
      throw new Exception(message);  
  }
}
 

