package se.bth.swatkats.letstalk.connection.packet.message;
import java.sql.Timestamp;
public class TextMessage extends Message {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3873427887735611133L;

	private String username;
	private String text;

	public String getText() {
		return text;
	}
	
	public void setText(String message) {
		this.text = message;
	}

	public TextMessage(int receiver, String message) {
		super(receiver);
		this.text = message;
	}
	
	public TextMessage(int senderid, String username, String text, Timestamp time, int id){
		super(senderid,time,id);
		this.username = username;
		this.text = text;
		
	}

	public String getUsername() {
		return username;
	}

}
