package se.bth.swatkats.letstalk.connection;

import java.util.ArrayList;

import se.bth.swatkats.letstalk.Constants;
import se.bth.swatkats.letstalk.connection.packet.DatabaseQuery;
import se.bth.swatkats.letstalk.connection.packet.LoginMessage;
import se.bth.swatkats.letstalk.connection.packet.message.FileMessage;
import se.bth.swatkats.letstalk.connection.packet.message.TextMessage;
import se.bth.swatkats.letstalk.gui.Conversation;
import se.bth.swatkats.letstalk.gui.HomePage;
import se.bth.swatkats.letstalk.user.User;

/**
 * This class acts as interface between
 * 
 * @author Sokratis & JS
 */
@SuppressWarnings("unchecked")
public class GuiHandler implements IDatabase {

	private Connection conn;
	private User user;
	private Object databaseresult = null;

	private HomePage gui;

	private static volatile GuiHandler instance;

	public static GuiHandler getInstance() {
		if (instance == null) {
			synchronized (GuiHandler.class) {
				if (instance == null) {
					instance = new GuiHandler();
				}
			}
		}
		return instance;
	}

	public User getUser() {
		return user;
	}

	/**
	 * Establish connection to server and database, if not done yet.
	 * 
	 * @return true if successful, false if not.
	 */
	public boolean openConnection() {
		if (conn.isConnected()) {
			return true;
		}
		return conn.openConnection(Constants.HOST, Constants.SERVERPORT);
	}

	public int login(String usernameGiven, String passwordGiven) {
		LoginMessage m = new LoginMessage(usernameGiven, passwordGiven);
		int temp = conn.sendLoginObject(m);
		user = new User(temp, usernameGiven, null, 0, 0);
		return temp;
	}

	/**
	 * Sends a message to the given clientid.
	 * 
	 * @param receiverid
	 *            the userid of the receiver
	 * @param text
	 *            the text message
	 * @return true if successful, false if not
	 */
	public boolean sendMessage(int receiverid, String text) {
		TextMessage m = new TextMessage(receiverid, text);
		return conn.sendMessageObject(m);
	}

	/**
	 * Called to close the connection to the server.
	 * 
	 * @return true if successful, false if not
	 */
	public boolean closeConnection() {
		conn.closeConnection();
		return true;
	}

	/**
	 * Method is called if the GUI receives a new TextMessage from a different
	 * client.
	 * 
	 * @param senderid
	 *            the id of the sender
	 * @param text
	 *            the received text
	 */
	public void receiveTextMessage(TextMessage m) {
		if(gui==null){
			System.err.print("GUI has not been set yet.");
		}
		gui.receivedMessage(m);
	}

	private synchronized Object execute(String method, Object... params) {
		DatabaseQuery query = new DatabaseQuery(method, params);
		databaseresult = null;
		conn.sendMessageObject(query);
		while (databaseresult == null) {
			// wait until databaseresult has the result stored
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		// clear databaseresult again
		Object answer = databaseresult;
		databaseresult = null;
		return answer;
	}

	public void receiveDatabaseResult(Object result) {
		databaseresult = result;
	}

	@Override
	public Integer changeUserPassword(Integer user_id, String username,
			String oldPass, String newPass) {
		return (Integer) execute(Thread.currentThread()
				.getStackTrace()[1].getMethodName(), user_id, username,
				oldPass, newPass);
	}

	@Override
	public Boolean setUserStatusAvailable(Integer userid) {
		return (Boolean) execute(
				Thread.currentThread().getStackTrace()[1].getMethodName(),
				userid);
	}

	@Override
	public Boolean setUserStatusBusy(Integer userid) {
		return (Boolean) execute(
				Thread.currentThread().getStackTrace()[1].getMethodName(),
				userid);
	}

	@Override
	public ArrayList<User> searchLocalUsers(Integer user_id, String phrase) {
		if(phrase==null){
			phrase = "";
		}
		return (ArrayList<User>) execute(
				Thread.currentThread().getStackTrace()[1].getMethodName(),
				user_id, phrase);
	}

	@Override
	public Integer createUser(String username, String password, String email,
			Boolean isAdmin) {
		return (Integer) execute(
				Thread.currentThread().getStackTrace()[1].getMethodName(),
				username, password, email, isAdmin);
	}

	@Override
	public Integer createConversation(Integer user_one, Integer user_two, Integer chat_type, String g_name) {
		return (Integer) execute(
				Thread.currentThread().getStackTrace()[1].getMethodName(),
				user_one, user_two, chat_type, g_name);
	}

	@Override
	public ArrayList<User> searchGlobalUsers(String phrase, Integer user_id) {
		return (ArrayList<User>) execute(
				Thread.currentThread().getStackTrace()[1].getMethodName(),
				phrase, user_id);
	}

	@Override
	public ArrayList<Conversation> fetchConversationsForUser(Integer user_id) {
		return (ArrayList<Conversation>) execute(Thread.currentThread()
				.getStackTrace()[1].getMethodName(), user_id);
	}

	@Override
	public ArrayList<FileMessage> fetchFileConversationHistory(
			Integer conversationId, Integer user_id) {
		return (ArrayList<FileMessage>) execute(Thread.currentThread()
				.getStackTrace()[1].getMethodName(), conversationId, user_id);
	}

	@Override
	public ArrayList<TextMessage> fetchTextConversationHistory(
			Integer conversationId, Integer user_id) {
		return (ArrayList<TextMessage>) execute(Thread.currentThread()
				.getStackTrace()[1].getMethodName(),conversationId, user_id);
	}

	@Override
	public Boolean addLocalUser(Integer user_current, Integer user_to_add) {
		return (Boolean) execute(Thread.currentThread()
				.getStackTrace()[1].getMethodName(), user_current, user_to_add);
	}

	@Override
	public Boolean deleteUserFromLocalBook(Integer userID, Integer receiverID) {
		return (Boolean) execute(Thread.currentThread()
				.getStackTrace()[1].getMethodName(), userID, receiverID);
	}

	@Override
	public Boolean blockUserFromLocalBook(Integer user_id_by, Integer user_id_to) {
		return (Boolean) execute(Thread.currentThread()
				.getStackTrace()[1].getMethodName(), user_id_by, user_id_to);
	}

	@Override
	public Boolean unblockUserFromLocalBook(Integer user_id_by, Integer user_id_to) {
		return (Boolean) execute(Thread.currentThread()
				.getStackTrace()[1].getMethodName(), user_id_by, user_id_to);
	}

	@Override
	public Boolean deleteUser(Integer user_id) {
		return (Boolean) execute(Thread.currentThread()
				.getStackTrace()[1].getMethodName(), user_id);
	}
	

	/**
	 * @return the conn
	 */
	public Connection getConn() {
		return conn;
	}

	/**
	 * @param conn the conn to set
	 */
	public void setConn(Connection conn) {
		this.conn = conn;
	}

	/**
	 * @return the databaseresult
	 */
	public Object getDatabaseresult() {
		return databaseresult;
	}

	/**
	 * @param databaseresult the databaseresult to set
	 */
	public void setDatabaseresult(Object databaseresult) {
		this.databaseresult = databaseresult;
	}

	/**
	 * @return the gui
	 */
	public HomePage getGui() {
		return gui;
	}

	/**
	 * @param gui the gui to set
	 */
	public void setGui(HomePage gui) {
		this.gui = gui;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		this.user = user;
	}

	private GuiHandler() {
		super();
		// clientid is unknown yet
		conn = new Connection(-10);
	}

}
