package se.bth.swatkats.letstalk.file.upload;

import java.io.File;
import java.util.Observable;  
import java.io.FileInputStream;  
import java.io.ObjectInputStream;  
import java.io.ObjectOutputStream;  
import java.net.Socket;  
import java.util.Observer;
import java.util.ArrayList;

import se.bth.swatkats.letstalk.Constants;

  
public class fileupload extends Observable{  
	private static final int BUFFER_SIZE = 4096; 
	private long FILE_SIZE,UPLOADED=0;
	private Socket socket;
	private File file;
	private ArrayList<Observer> users=new ArrayList<Observer>();
    public fileupload(String path) throws Exception {  
        this.file = new File(path); 
        this.socket = new Socket(Constants.HOST, 2389);
    }
    public long getValue()
    {
       return (UPLOADED/FILE_SIZE)*100;
    }
    public void addObserver(Observer observer){
        users.add(observer);		
     }
    public void removeObserver(Observer observer){
        users.remove(observer);		
     }
    public void sendFile(int fileid)throws Exception{
        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());  
        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());  
  
        oos.writeInt(fileid);
        this.FILE_SIZE=file.length();
        oos.writeLong(FILE_SIZE);
        oos.writeObject(getFileExtension(file.getName()));
        
        FileInputStream fis = new FileInputStream(file);  
        byte [] buffer = new byte[BUFFER_SIZE];  
        Integer bytesRead ;
        bytesRead = new Integer(fis.read(buffer));
        while (bytesRead.intValue() > 0) {  
            oos.writeObject(bytesRead);  
            oos.write(buffer); 
            this.UPLOADED=UPLOADED+bytesRead.longValue();
            setChanged();
            notifyObservers();
        }  
  
        oos.close();  
        ois.close();  
        System.exit(0);      
} 
    
    private static String getFileExtension(String fileName) {
        if(fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
        return fileName.substring(fileName.lastIndexOf(".")+1);
        else return "";
    } 
}  
  
   
