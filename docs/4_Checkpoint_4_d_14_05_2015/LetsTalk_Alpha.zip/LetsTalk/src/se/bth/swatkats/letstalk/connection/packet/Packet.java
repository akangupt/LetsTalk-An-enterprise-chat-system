package se.bth.swatkats.letstalk.connection.packet;

import java.io.Serializable;

import se.bth.swatkats.letstalk.user.User;

public abstract class Packet implements Serializable {

	/**
	 * Generated
	 */
	private static final long serialVersionUID = -444519389366236917L;
	
	private String senderip;

	private int receiverid;

	public String getSenderip() {
		return senderip;
	}

	public void setSenderip(String senderip) {
		this.senderip = senderip;
	}

	public int getReceiverid() {
		return receiverid;
	}

	public void setReceiver(int receiver) {
		this.receiverid = receiver;
	}
	
	public Packet(int receiver) {
		super();
		this.receiverid = receiver;
	}

}
