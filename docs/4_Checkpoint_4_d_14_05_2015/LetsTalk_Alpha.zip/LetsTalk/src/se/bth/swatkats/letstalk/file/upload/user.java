package se.bth.swatkats.letstalk.file.upload;
import java.util.Observer;
import java.util.Observable;
public class user implements Observer {
	private long uploaded;
	private fileupload file;
	public user(fileupload file){
	      this.file = file;
	   }
@Override
	   public void update(Observable obs, Object obj) {
		if (obs == file)
		{
		   this.uploaded=file.getValue(); 
	   }
}
}
