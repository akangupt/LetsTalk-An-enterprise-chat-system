package se.bth.swatkats.letstalk.gui;

import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.ArrayList;
import javax.swing.JFileChooser;
import static javax.swing.JOptionPane.showMessageDialog;
import se.bth.swatkats.letstalk.connection.GuiHandler;
import se.bth.swatkats.letstalk.connection.packet.message.FileMessage;
import se.bth.swatkats.letstalk.connection.packet.message.Message;
import se.bth.swatkats.letstalk.connection.packet.message.TextMessage;
import se.bth.swatkats.letstalk.user.User;

/**
 * This class provides the window which has all the funtionalities that can be used by the user.
 * 
 * @author Sokratis Papadopoulos and David Alarcon Prada.
 */
public class HomePage extends javax.swing.JFrame {
    private User user; //current user
    ArrayList<User> contacts; //users in local address book
    ArrayList<Conversation> conversations; //conv_id, name, timestamp_of_last_message

    /**
     * Creates new form HomePage.
     */
    public HomePage() {
        
        // Structuring the interface
        initComponents();  
        myInitComponents();
    }
    
    public void updateConversations(){
        //fetching all conversations for our current user from the database
        System.out.println("Time to fetch conversations");
        conversations = GuiHandler.getInstance().fetchConversationsForUser(user.getId());
        
        //adds conversations to the conversation list of current user.
        conversationsList.setModel(new javax.swing.AbstractListModel() {
            String[] strings = putNames();
            @Override
            public int getSize() { return strings.length; }
            @Override
            public Object getElementAt(int i) { return strings[i]; }
       });
    }
    
    public void updateContacts(){
        //fetching all contacts (people in local address book) for our current user from database
        System.out.println("Time to fetch contacts");
        contacts = GuiHandler.getInstance().searchLocalUsers(user.getId(), null);
        
        //insert the contacts in local address book of current user.		
        localAddressBookList.setModel(new javax.swing.AbstractListModel() {		
            String[] strings = insertContacts();		
            @Override		
            public int getSize() { return strings.length; }		
            @Override		
            public Object getElementAt(int i) { return strings[i]; }		
        });          
    }

    /**
     * Provides modifications written by us.
     */
    private void myInitComponents(){
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("img/iconHead.png")));
        
        //setting what happens upon closure of main homepage window.
        this.addWindowListener(new WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent event){
                exitProcedure();
            }
        });
        
        // link to the gui handler
        user = GuiHandler.getInstance().getUser();
        GuiHandler.getInstance().setGui(this);
        contacts = new ArrayList<>();
        conversations = new ArrayList<>();
        
        updateConversations();
        updateContacts();
 
    }
    
    /**
     * Inserts into the local address book the names of user's contacts.
     * 
     * @return temp - the local address book strings (usernames).
     */
    private String[] insertContacts() {
        System.out.println("===insert contacts==== " + contacts.size());
        String[] temp = new String[contacts.size()];
        int pos=0;
        for(User contact: contacts){
            temp[pos++] = contact.getUsername();
            System.out.println(contact.getUsername());
        }
        return temp;
    }
    
    /**
     * Inserts into the left list, the conversations.
     * 
     * @return the conversations strings (conversations names).
     */
    private String[] putNames() {
        System.out.println("=====insert conversations===== " + conversations.size());
        String[] temp = new String[conversations.size()];
        int pos=0;
        for(Conversation conv: conversations){
            temp[pos++] = conv.getName();
            System.out.println(conv.getName());
        }
        return temp;
    }
    
    /**
     * Called when user exits our application.
     * It aborts the connection and then close the window.
     */
    private void exitProcedure(){
        setVisible(false); //you can't see me!
        dispose(); //Destroy the JFrame object
        GuiHandler.getInstance().closeConnection(); //closes connection with server.
        System.exit(1); //terminates the program.
    }
    
    /**
     * Manages the received messages. If it is a normal message is showed
     * in the screen, if not... [WE WILL SEE]
     * 
     * @param m - received message. 
     */
    public void receivedMessage(Message m){
        if(m instanceof TextMessage)
            messageHistoryTextArea.append( ((TextMessage) m).getUsername() + ": " + ((TextMessage) m).getText() + System.getProperty("line.separator") );
        else
            messageHistoryTextArea.append( ((FileMessage) m).getUsername() + ": " + ((FileMessage) m).getFilename()+ System.getProperty("line.separator") );    
    }
    
   /**
     * Every time user selects another conversation, the new message history
     * is loaded.
     * 
     * @param e - event.
     * */
    private void conversationsListValueChanged(javax.swing.event.ListSelectionEvent e){
        messageHistoryTextArea.setText("");
        String selectedName = conversationsList.getSelectedValue().toString();
        showMessageDialog(null, selectedName);
        
        for(Conversation conv : conversations){
            if (conv.getName().equals(selectedName)){
                ArrayList<TextMessage> messages = GuiHandler.getInstance().fetchTextConversationHistory(conv.getId(), user.getId());

                for(Message m : messages){
                    if(m instanceof TextMessage)
                        messageHistoryTextArea.append( ((TextMessage) m).getUsername() + ": " + ((TextMessage) m).getText() + System.getProperty("line.separator") );
                    else
                        messageHistoryTextArea.append( "file" + System.getProperty("line.separator") ); //filemessage
                }
            }
        }       
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jMenu1 = new javax.swing.JMenu();
        userStatus = new javax.swing.ButtonGroup();
        messageHistoryScrollPane = new javax.swing.JScrollPane();
        messageHistoryTextArea = new javax.swing.JTextArea();
        sendMessagePanel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        sendMessageTextPane = new javax.swing.JTextPane();
        attachFile = new javax.swing.JButton();
        sendTextBut = new javax.swing.JButton();
        conversationsPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        conversationsList = new javax.swing.JList();
        logo = new javax.swing.JLabel();
        localAddresBookScrollPane = new javax.swing.JScrollPane();
        localAddressBookList = new javax.swing.JList();
        newConversationButton = new javax.swing.JButton();
        menuBar = new javax.swing.JMenuBar();
        settingsMenu = new javax.swing.JMenu();
        changePasswordMenu = new javax.swing.JMenuItem();
        statusMenu = new javax.swing.JMenu();
        statusAvailableSubMenu = new javax.swing.JRadioButtonMenuItem();
        statusBusySubMenu = new javax.swing.JRadioButtonMenuItem();
        addressBookMenu = new javax.swing.JMenu();
        addDeleteUserSubMenu = new javax.swing.JMenuItem();
        blockUnblockUserSubMenu = new javax.swing.JMenuItem();
        adminFeaturesMenu = new javax.swing.JMenu();
        adminPanelSubMenu = new javax.swing.JMenuItem();
        statisticsMenu = new javax.swing.JMenu();
        checkStatsSubMenu = new javax.swing.JMenuItem();
        materialRepoMenu = new javax.swing.JMenu();
        filesDatabaseSubMenu = new javax.swing.JMenuItem();
        helpMenu = new javax.swing.JMenu();
        aboutSubMenu = new javax.swing.JMenuItem();

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        jMenu1.setText("jMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Lets Talk");
        setBackground(new java.awt.Color(247, 247, 247));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setResizable(false);

        messageHistoryScrollPane.setBorder(javax.swing.BorderFactory.createTitledBorder("Message History"));
        messageHistoryScrollPane.setAutoscrolls(true);
        messageHistoryScrollPane.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        messageHistoryTextArea.setColumns(20);
        messageHistoryTextArea.setRows(5);
        messageHistoryTextArea.setFocusable(false);
        messageHistoryScrollPane.setViewportView(messageHistoryTextArea);

        sendMessagePanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Send a message"));

        jScrollPane2.setViewportView(sendMessageTextPane);

        attachFile.setText("Attach File");
        attachFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attachFileActionPerformed(evt);
            }
        });

        sendTextBut.setText("Send Text");
        sendTextBut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendTextButActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout sendMessagePanelLayout = new javax.swing.GroupLayout(sendMessagePanel);
        sendMessagePanel.setLayout(sendMessagePanelLayout);
        sendMessagePanelLayout.setHorizontalGroup(
            sendMessagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, sendMessagePanelLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 744, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(sendMessagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(attachFile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(sendTextBut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(2, 2, 2))
        );
        sendMessagePanelLayout.setVerticalGroup(
            sendMessagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
            .addGroup(sendMessagePanelLayout.createSequentialGroup()
                .addComponent(attachFile, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(sendTextBut, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        conversationsPanel.setBorder(javax.swing.BorderFactory.createTitledBorder("Conversations"));
        conversationsPanel.setName(""); // NOI18N
        conversationsPanel.setOpaque(false);

        conversationsList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                conversationsListValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(conversationsList);

        javax.swing.GroupLayout conversationsPanelLayout = new javax.swing.GroupLayout(conversationsPanel);
        conversationsPanel.setLayout(conversationsPanelLayout);
        conversationsPanelLayout.setHorizontalGroup(
            conversationsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(conversationsPanelLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        conversationsPanelLayout.setVerticalGroup(
            conversationsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 467, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/se/bth/swatkats/letstalk/gui/img/logoSmall.png"))); // NOI18N
        logo.setPreferredSize(new java.awt.Dimension(500, 256));
        logo.setRequestFocusEnabled(false);

        localAddresBookScrollPane.setBorder(javax.swing.BorderFactory.createTitledBorder("Local Address Book"));
        localAddresBookScrollPane.setToolTipText("");

        localAddressBookList.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        localAddresBookScrollPane.setViewportView(localAddressBookList);

        newConversationButton.setText("New conversation");
        newConversationButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newConversationButtonActionPerformed(evt);
            }
        });

        menuBar.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        menuBar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        settingsMenu.setText("Settings");
        settingsMenu.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        changePasswordMenu.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        changePasswordMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/se/bth/swatkats/letstalk/gui/img/changePass.png"))); // NOI18N
        changePasswordMenu.setText("Change Password");
        changePasswordMenu.setAutoscrolls(true);
        changePasswordMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changePasswordMenuActionPerformed(evt);
            }
        });
        settingsMenu.add(changePasswordMenu);

        menuBar.add(settingsMenu);

        statusMenu.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        statusMenu.setText("Status");
        statusMenu.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        statusAvailableSubMenu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        userStatus.add(statusAvailableSubMenu);
        statusAvailableSubMenu.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        statusAvailableSubMenu.setSelected(true);
        statusAvailableSubMenu.setText("Available");
        statusAvailableSubMenu.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        statusAvailableSubMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/se/bth/swatkats/letstalk/gui/img/green.png"))); // NOI18N
        statusAvailableSubMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                statusAvailableSubMenuActionPerformed(evt);
            }
        });
        statusMenu.add(statusAvailableSubMenu);

        statusBusySubMenu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_MASK));
        userStatus.add(statusBusySubMenu);
        statusBusySubMenu.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        statusBusySubMenu.setText("Busy");
        statusBusySubMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/se/bth/swatkats/letstalk/gui/img/red.png"))); // NOI18N
        statusBusySubMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                statusBusySubMenuActionPerformed(evt);
            }
        });
        statusMenu.add(statusBusySubMenu);

        menuBar.add(statusMenu);

        addressBookMenu.setText("Address Book");
        addressBookMenu.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        addDeleteUserSubMenu.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        addDeleteUserSubMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/se/bth/swatkats/letstalk/gui/img/manageUser.png"))); // NOI18N
        addDeleteUserSubMenu.setText("Add/Delete User");
        addDeleteUserSubMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addDeleteUserSubMenuActionPerformed(evt);
            }
        });
        addressBookMenu.add(addDeleteUserSubMenu);

        blockUnblockUserSubMenu.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        blockUnblockUserSubMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/se/bth/swatkats/letstalk/gui/img/blockUnblock.png"))); // NOI18N
        blockUnblockUserSubMenu.setText("Block/Unblock User");
        blockUnblockUserSubMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                blockUnblockUserSubMenuActionPerformed(evt);
            }
        });
        addressBookMenu.add(blockUnblockUserSubMenu);

        menuBar.add(addressBookMenu);

        adminFeaturesMenu.setText("Admin Features");
        adminFeaturesMenu.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        adminPanelSubMenu.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        adminPanelSubMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/se/bth/swatkats/letstalk/gui/img/user_admin.png"))); // NOI18N
        adminPanelSubMenu.setText("Open admin panel");
        adminPanelSubMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminPanelSubMenuActionPerformed(evt);
            }
        });
        adminFeaturesMenu.add(adminPanelSubMenu);

        menuBar.add(adminFeaturesMenu);

        statisticsMenu.setText("Statistics");
        statisticsMenu.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        checkStatsSubMenu.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        checkStatsSubMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/se/bth/swatkats/letstalk/gui/img/stats.png"))); // NOI18N
        checkStatsSubMenu.setText("Check your stats");
        checkStatsSubMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkStatsSubMenuActionPerformed(evt);
            }
        });
        statisticsMenu.add(checkStatsSubMenu);

        menuBar.add(statisticsMenu);

        materialRepoMenu.setText("Material Repository");
        materialRepoMenu.setFocusable(false);
        materialRepoMenu.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        filesDatabaseSubMenu.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        filesDatabaseSubMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/se/bth/swatkats/letstalk/gui/img/files.png"))); // NOI18N
        filesDatabaseSubMenu.setText("Open files database");
        filesDatabaseSubMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filesDatabaseSubMenuActionPerformed(evt);
            }
        });
        materialRepoMenu.add(filesDatabaseSubMenu);

        menuBar.add(materialRepoMenu);

        helpMenu.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        helpMenu.setText("Help");
        helpMenu.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        aboutSubMenu.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        aboutSubMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/se/bth/swatkats/letstalk/gui/img/information.png"))); // NOI18N
        aboutSubMenu.setText("About");
        aboutSubMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutSubMenuActionPerformed(evt);
            }
        });
        helpMenu.add(aboutSubMenu);

        menuBar.add(helpMenu);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(conversationsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(sendMessagePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(messageHistoryScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 751, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(localAddresBookScrollPane)
                            .addComponent(newConversationButton, javax.swing.GroupLayout.DEFAULT_SIZE, 167, Short.MAX_VALUE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(conversationsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(newConversationButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(localAddresBookScrollPane))
                            .addComponent(messageHistoryScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(11, 11, 11)
                        .addComponent(sendMessagePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(31, 31, 31))
        );

        setSize(new java.awt.Dimension(1203, 691));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * When user presses the Attach File button, is opened a new window where
     * the user can choose the file that he wants to send and send it.
     * 
     * @param evt - event.
     */
    private void attachFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attachFileActionPerformed
        // TODO: attach a file and transfer it!
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
        int result = fileChooser.showOpenDialog(fileChooser);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            //call an object of uploadfile with parameter the path.            
            System.out.println("Selected file: " + selectedFile.getAbsolutePath());
        }
    }//GEN-LAST:event_attachFileActionPerformed

    /**
     * When user presses the send button, it sends the text to the user specified 
     * in the conversation and cleans the send text area.
     * 
     * @param evt - event.
     */
    private void sendTextButActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendTextButActionPerformed
        // TODO send a text to the user requested!
        GuiHandler.getInstance().sendMessage(conversations.get(conversationsList.getSelectedIndex()).getId(),sendMessageTextPane.getText());
        messageHistoryTextArea.append(user.getUsername()+ ": " + sendMessageTextPane.getText() + System.getProperty("line.separator"));
        sendMessageTextPane.setText(""); //clears the sendTextArea 
        
    }//GEN-LAST:event_sendTextButActionPerformed
   
    /**
     * When user presses this option, his/her status is changed to available.
     * 
     * @param evt - event.
     */
    private void statusAvailableSubMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_statusAvailableSubMenuActionPerformed
        GuiHandler.getInstance().setUserStatusAvailable(user.getId());
        user.setStatus(0);
    }//GEN-LAST:event_statusAvailableSubMenuActionPerformed
    
    /**
     * When user presses this option, his/her status is changed to busy.
     * 
     * @param evt - event.
     */
    private void statusBusySubMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_statusBusySubMenuActionPerformed
        GuiHandler.getInstance().setUserStatusBusy(user.getId());
        user.setStatus(1);
    }//GEN-LAST:event_statusBusySubMenuActionPerformed
    
    /**
     * When user presses this option, a new window is displayed for change password.
     * 
     * @param evt - event.
     */
    private void changePasswordMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changePasswordMenuActionPerformed
        ChangePassword changePass = new ChangePassword();
        changePass.setVisible(true);
    }//GEN-LAST:event_changePasswordMenuActionPerformed
    
    /**
     * When user presses this option, a new window is displayed for add/delete users.
     * 
     * @param evt - event.
     */
    private void addDeleteUserSubMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addDeleteUserSubMenuActionPerformed
        AddDeleteUser addDeleteWin = new AddDeleteUser();
        addDeleteWin.setVisible(true);
        
        addDeleteWin.addWindowListener(new WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent event){
                System.out.println("window closed for addDelete");
                updateContacts();
            }
        });
    }//GEN-LAST:event_addDeleteUserSubMenuActionPerformed
    
    /**
     * When user presses this option, a new window is displayed for block/unblock users.
     * 
     * @param evt - event.
     */
    private void blockUnblockUserSubMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_blockUnblockUserSubMenuActionPerformed
        BlockUnblockUser blockUnblock = new BlockUnblockUser();
        blockUnblock.setVisible(true);
    }//GEN-LAST:event_blockUnblockUserSubMenuActionPerformed
    
    /**
     * When user presses this option, a new window is displayed for see the file repository.
     * 
     * @param evt - event. 
     */
    private void filesDatabaseSubMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filesDatabaseSubMenuActionPerformed
        FilesRepo filesWin = new FilesRepo();
        filesWin.setVisible(true);
    }//GEN-LAST:event_filesDatabaseSubMenuActionPerformed
    
    /**
     * When user presses this option, a new window is displayed for see details about the program.
     * 
     * @param evt - event. 
     */
    private void aboutSubMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutSubMenuActionPerformed
    	// open window for see details about the program
    	About aboutWin = new About();
    	aboutWin.setVisible(true);
    }//GEN-LAST:event_aboutSubMenuActionPerformed
    
    /**
     * When user presses this option, a new window is displayed for change admin features.
     * 
     * @param evt - event.
     */
    private void adminPanelSubMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminPanelSubMenuActionPerformed
    	AdminFeatures adminP = new AdminFeatures();
    	adminP.setVisible(true);
    }//GEN-LAST:event_adminPanelSubMenuActionPerformed
    
    /**
     * When user presses this option, a new window is displayed for see the resources' statistics.
     * 
     * @param evt - e.
     */
    private void checkStatsSubMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkStatsSubMenuActionPerformed
        Statistics statsWin = new Statistics();
        statsWin.setVisible(true);
    }//GEN-LAST:event_checkStatsSubMenuActionPerformed
    
    /**
     * When user presses this option, a new window is displayed for create a new conversation.
     * 
     * @param evt - event.
     */
    private void newConversationButtonActionPerformed(java.awt.event.ActionEvent evt){
        NewConversation newCnvWin = new NewConversation();
        newCnvWin.setVisible(true);
        newCnvWin.addWindowListener(new WindowAdapter(){
            @Override
            public void windowClosing(WindowEvent event){
                updateConversations();
            }
        });
    }
    
    /**
     * Main method which starts the class.
     * 
     * @param args - the command line arguments.
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomePage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem aboutSubMenu;
    private javax.swing.JMenuItem addDeleteUserSubMenu;
    private javax.swing.JMenu addressBookMenu;
    private javax.swing.JMenu adminFeaturesMenu;
    private javax.swing.JMenuItem adminPanelSubMenu;
    private javax.swing.JButton attachFile;
    private javax.swing.JMenuItem blockUnblockUserSubMenu;
    private javax.swing.JMenuItem changePasswordMenu;
    private javax.swing.JMenuItem checkStatsSubMenu;
    private javax.swing.JList conversationsList;
    private javax.swing.JPanel conversationsPanel;
    private javax.swing.JMenuItem filesDatabaseSubMenu;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane localAddresBookScrollPane;
    private javax.swing.JList localAddressBookList;
    private javax.swing.JLabel logo;
    private javax.swing.JMenu materialRepoMenu;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JScrollPane messageHistoryScrollPane;
    private javax.swing.JTextArea messageHistoryTextArea;
    private javax.swing.JButton newConversationButton;
    private javax.swing.JPanel sendMessagePanel;
    private javax.swing.JTextPane sendMessageTextPane;
    private javax.swing.JButton sendTextBut;
    private javax.swing.JMenu settingsMenu;
    private javax.swing.JMenu statisticsMenu;
    private javax.swing.JRadioButtonMenuItem statusAvailableSubMenu;
    private javax.swing.JRadioButtonMenuItem statusBusySubMenu;
    private javax.swing.JMenu statusMenu;
    private javax.swing.ButtonGroup userStatus;
    // End of variables declaration//GEN-END:variables
}
