package se.bth.swatkats.letstalk.connection.packet.message;

import java.sql.Timestamp;

public class FileMessage extends Message {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6211493495565200646L;

	private String filename, username;
	private int file_id;
	
	public String getFilename(){
		return filename;
	}
	
	public int getFileid(){
		return file_id;
	}
	
	public String getUsername(){
		return username;
	}

	public FileMessage(int senderid, String username, String filename, int file_id, Timestamp time, int id){
		super(senderid,time,id);
		this.file_id = file_id;
		this.filename = filename;
		this.username = username;
	}
	
}
