package se.bth.swatkats.letstalk.connection.packet.message;

import java.sql.Timestamp;

import se.bth.swatkats.letstalk.connection.packet.Packet;

public abstract class Message extends Packet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2537491720091187268L;

	private int senderid;

	private Timestamp timestamp;

	/**
	 * @return the timestamp
	 */
	public Timestamp getTimestamp() {
		return timestamp;
	}

	/**
	 * @param timestamp
	 *            the timestamp to set
	 */
	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	public int getSenderid() {
		return senderid;
	}

	public void setSenderid(int sender) {
		this.senderid = sender;
	}

	public Message(int receiver) {
		super(receiver);
		setTimestamp(new Timestamp(System.currentTimeMillis()));
	}
	public Message(int senderid, Timestamp time , int id) {
		super(id);
		this.senderid = senderid;
		this.timestamp = time;
		
		
	}

}
