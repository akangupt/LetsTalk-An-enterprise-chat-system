package se.bth.swatkats.letstalk;

/**
 * A class containing all the constants needed.
 * 
 * @author JS
 *
 */
public class Constants {

	/**
	 * The port to be used to connect from client to server
	 */
	public static final int SERVERPORT = 6677;

	/**
	 * The host to connect to
	 */
	public final static String HOST = "localhost";

	/**
	 * The unique id of the server
	 */
	public final static int SERVERID = 0;

	/**
	 * The symmetric encryption algorithm to use
	 */
	public static final String ENC_ALGO = "AES";

	/**
	 * The message digest algorithm to use
	 */
	public static final String MSG_DIG_ALGO = "SHA-256";

	/**
	 * The Key size for the AES encryption
	 */
	public static final int AES_KEY_SIZE = 128;

	/**
	 * Parameters for Key Generation in key exchange
	 */
	public static final String KEY_GEN_PARAM = "DH";

	/**
	 * Parameters for Number of bits in Key Generation
	 */
	public static final int KEY_GEN_BITS = 1024;

	/**
	 * Transformation parameter
	 */
	public static final String transformation = "AES/ECB/PKCS5Padding";

}
