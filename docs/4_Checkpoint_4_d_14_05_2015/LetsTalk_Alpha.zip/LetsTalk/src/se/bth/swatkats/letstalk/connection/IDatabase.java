package se.bth.swatkats.letstalk.connection;

import se.bth.swatkats.letstalk.gui.Conversation;
import se.bth.swatkats.letstalk.connection.packet.message.FileMessage;
import java.util.ArrayList;
import java.util.List;

import se.bth.swatkats.letstalk.connection.packet.message.Message;
import se.bth.swatkats.letstalk.connection.packet.message.TextMessage;
import se.bth.swatkats.letstalk.gui.Conversation;
import se.bth.swatkats.letstalk.user.User;

public interface IDatabase {

	/**
	 * Fetches the local address book of the user from the server.
	 * 
	 * @param userid
	 *            the id of the user
	 * 
	 * @return list with users with information
	 */
	public ArrayList<User> searchLocalUsers(Integer user_id, String phrase);

	/**
	 * Fetches the conversation informations.
	 * 
	 * @param conversationID
	 *            the id of the converstation
	 * @return
	 */
	public ArrayList<TextMessage> fetchTextConversationHistory(
			Integer conversationId, Integer user_id);

	/**
	 * Changes the password of the specified user in the database.
	 * 
	 * @param userID
	 * @param oldPass
	 * @param newPass
	 * @return
	 */
	public Integer changeUserPassword(Integer user_id, String username,
			String oldPass, String newPass);

	/**
	 * Sets the user status as available in the database
	 *
	 * @param userID
	 * @return
	 */
	public Boolean setUserStatusAvailable(Integer userid);

	/**
	 * Sets the user status as busy in the database
	 *
	 * @param userID
	 * @return
	 */
	public Boolean setUserStatusBusy(Integer userid);

	/**
	 * Adds a user to the local address book.
	 *
	 * @param userID
	 * @param receiverID
	 * @return true if success, false if fail
	 */
	public Boolean addLocalUser(Integer user_current, Integer user_to_add);

	/**
	 * Deletes a user from the local address book.
	 *
	 * @param userID
	 * @param receiverID
	 * @return true if success, false if fail
	 */
	public Boolean deleteUserFromLocalBook(Integer userID, Integer receiverID);

	/**
	 * Blocks a user from the local address book.
	 *
	 * @param userID
	 * @param receiverID
	 * @return true if success, false if fail
	 */
	public Boolean blockUserFromLocalBook(Integer user_id_by, Integer user_id_to);

	/**
	 * Unblocks a user from the local address book.
	 *
	 * @param userID
	 * @param receiverID
	 * @return true if success, false if fail
	 */
	public Boolean unblockUserFromLocalBook(Integer user_id_by, Integer user_id_to);

	/**
	 * Deletes a user from the application.
	 *
	 * @param userID
	 * @return
	 */
	public Boolean deleteUser(Integer user_id);
	
	public Integer createUser(String username, String password, String email,
			Boolean isAdmin);

	public Integer createConversation(Integer user_one, Integer user_two, Integer chat_type, String g_name);

	public ArrayList<User> searchGlobalUsers(String phrase, Integer user_id);

	public ArrayList<Conversation> fetchConversationsForUser(Integer user_id);

	public ArrayList<FileMessage> fetchFileConversationHistory(
			Integer conversationId, Integer user_id);

}
