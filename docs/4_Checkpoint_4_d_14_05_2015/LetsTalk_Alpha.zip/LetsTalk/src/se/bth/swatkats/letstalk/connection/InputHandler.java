package se.bth.swatkats.letstalk.connection;

import se.bth.swatkats.letstalk.connection.packet.DatabaseQuery;
import se.bth.swatkats.letstalk.connection.packet.LoginMessage;
import se.bth.swatkats.letstalk.connection.packet.Packet;
import se.bth.swatkats.letstalk.connection.packet.message.TextMessage;

/**
 * This class is responsible for reacting on different kinds of Message Objects
 * on the client side
 * 
 * @author JS
 *
 */
public class InputHandler implements Runnable {

	private Packet in;

	public InputHandler(Packet in) {
		this.in = in;
	}

	@Override
	public void run() {
		if (in instanceof TextMessage) {
			TextMessage text = (TextMessage) in;
			GuiHandler.getInstance().receiveTextMessage(
					((TextMessage) in));
		} else if (in instanceof LoginMessage) {
			// ignore -- Login is handled somewhere else
		} else if (in instanceof DatabaseQuery) {
			GuiHandler.getInstance().receiveDatabaseResult(
					((DatabaseQuery) in).getResult());
		} else {
			System.err.print("Error. Message type not supported.");
		}
	}
}
