package se.bth.swatkats.letstalk.server.mail;

/*
Author : Akanksha Gupta
Send an email containing chat if other user is offline. 
*/

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class SendMail {
   public static void main(String[] args) {

      String to = "guptaaka95@gmail.com";   //change accordingly
      
      Properties props = new Properties();
      props.put("mail.smtp.host", "smtp.gmail.com");
      props.put("mail.smtp.auth", "true");
      props.put("mail.smtp.port", "587");
      props.put("mail.smtp.ssl.enable", "false");
      props.put("mail.smtp.starttls.enable", "true");
      props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
       
     Session session = Session.getInstance(props, 
    		 new javax.mail.Authenticator() {
         protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication("noreply.letstalk", "passwordforswatkats");
         }
     });
     
      try {
         Message message = new MimeMessage(session);   // Create a MimeMessage object.
         message.setFrom(new InternetAddress("noreply.letstalk@gmail.com"));    // Set From.
         message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to));    // Set To
         message.setSubject("Testing Subject");     // Set Subject
         message.setText("Hello, this is sample for to check send " + "email using JavaMailAPI ");       //change accordingly
         Transport.send(message);           // Send message
         System.out.println("Sent Successfully");
         } catch (MessagingException e) {
            throw new RuntimeException(e);
           }
   }
}