package se.bth.swatkats.letstalk.fileupload;

import java.io.File; 
import java.io.FileOutputStream;  
import java.io.ObjectInputStream;  
import java.io.ObjectOutputStream;  
import java.net.Socket;  
import java.net.ServerSocket; 
  
public class upload extends Thread {  
	private static final int PORT = 2389;  
    private static final int BUFFER_SIZE = 4096; 
    private long FILE_SIZE;
    
    public void run() {  
        try {  
            ServerSocket serverSocket = new ServerSocket(PORT);  
            while (true) {  
                Socket s = serverSocket.accept();  
                saveFile(s);  
            }  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
      
    private void saveFile(Socket socket) throws Exception {  
        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());  
        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());  
        FileOutputStream fos = null;  
        byte [] buffer = new byte[BUFFER_SIZE];  
  
        // 1. Read file name. 
        int id=ois.readInt();
        FILE_SIZE=ois.readLong();
        Object file = ois.readObject();  
  
        if (file instanceof String) {
        	File targetDirectory = new File("/home/files/");//wherever the server wants files to be saved
            fos = new FileOutputStream(new File (targetDirectory, String.valueOf(id)+file.toString()));  
        } else {  
            throwException("File name not received");  
        }  
  
        // 2. Read file to the end.  
        Integer bytesRead = new Integer(0);  
  
        do {  
            file = ois.readObject();  
  
            if (!(file instanceof Integer)) {  
                throwException("Number of bytes to be read not received");  
            }  
  
            bytesRead = (Integer)file;  
  
            try{
                ois.read(buffer,0,bytesRead.intValue());  
                }catch (Exception e) {
                  e.printStackTrace();
                }  
  
            // 3. Write data to output file.  
            fos.write(buffer, 0, bytesRead.intValue());  
            
        } while (bytesRead.intValue() == BUFFER_SIZE);  
          
        System.out.println("File transfer success");  
          
        fos.close();  
        ois.close();  
        oos.close();  
    }  
  
    public static void throwException(String message) throws Exception {  
        throw new Exception(message);  
    }
    public static void main(String[] args) {  
        new upload().start();  
    }  
} 

