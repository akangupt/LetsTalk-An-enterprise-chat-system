package se.bth.swatkats.letstalk.server.connection;
import com.mchange.v2.c3p0.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Reader;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import se.bth.swatkats.letstalk.server.connection.Database;
import se.bth.swatkats.letstalk.user.*;
import java.util.ArrayList;
import se.bth.swatkats.letstalk.Constants;
import se.bth.swatkats.letstalk.gui.Conversation;
import se.bth.swatkats.letstalk.connection.packet.message.TextMessage;
/**
 * The main class to start the Server functionality.
 * 
 * @author JS & Gautam
 *
 */
public class Main implements Runnable {

	private static HashMap<Integer, ClientHandler> onlineUsers;
	
	private static Database database;
	private static ComboPooledDataSource dataSource = new ComboPooledDataSource();
	
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost";
	static final String DB_URL_SC = "jdbc:mysql://localhost/swatchat2";
	static final String USER = "root";
	static final String PASS = "admin";
	static final String SQL_SCRIPT = "C:/Users/Sokratis/Desktop/GitLab/SWAT-Kats/src/LetsTalkServer/src/se/bth/swatkats/letstalk/server/connection/db_init.sql";

	public static void main(String[] args) {
		System.out.println("Starting Server.");
		// JDBC driver name and database URL
		Connection conn = null;
		Statement stmt = null;
		try {

			Class.forName("com.mysql.jdbc.Driver");

			//	Open a connection
			System.out.println("Connecting to server...");
			 
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			ScriptRunner sr = new ScriptRunner(conn, false, false);
			System.out.println("Creating database...");
			Reader reader = new BufferedReader(new FileReader(SQL_SCRIPT));
			sr.runScript(reader);
			System.out.println(" Database Constructed ");

			// passing conn descriptor in the database connection object
			conn = DriverManager.getConnection(DB_URL_SC, USER, PASS);
			
			System.out.println(" Shifting to new database ");
			dataSource.setDriverClass(JDBC_DRIVER);
			dataSource.setJdbcUrl(DB_URL_SC);
			dataSource.setUser(USER);
			dataSource.setPassword(PASS);
			
			conn = dataSource.getConnection();
			
			database = new Database(conn);
			System.out.println(" Database Successful ");
			System.out.println(database.createUser("g", "g_p",
					"gemail", false));
			System.out.println(database.createUser("g1", "g1_p",
					"g1email", false));
			System.out.println(database.createUser("g2", "g2_p",
					"g2email", false));
			System.out.println(database.createUser("g3", "g3_p",
					"g3email", false));
			System.out.println(database.createUser("g4", "g4_p",
					"g4email", false));
			System.out.println(database.createUser("g5", "g5_p",
					"g5email", false));
			System.out.println(database.createUser("g6", "g6_p",
					"g6email", false));
			System.out.println(database.createUser("g7", "g7_p",
					"g7email", false));
			System.out.println(database.createUser("g8", "g8_p",
					"g8email", false));
			System.out.println(database.createUser("g9", "g9_p",
					"g9email", false));
			System.out.println(database.authenticateLogin("g", "g_p"));
			System.out.println(database.createUser("g1", "g1_p",
					"g1email", false));
			
			System.out.println(database.authenticateLogin("g1", "g1_p"));
			System.out.println( database.changeUserPassword(2,"g3","g3_p", "love uh") );
			//database.deleteuser(1);
			// first argument: userid in whose phonebook contact to be added
			// second argument: userid of whose contact to be added
			database.addLocalUser(2, 3);
			database.addLocalUser(2, 4);
			database.addLocalUser(2, 5);
			database.addLocalUser(1, 2);
			database.addLocalUser(2, 1);
			database.addLocalUser(3, 2);
			System.out.println(database.createConversation(2, 3, 1,""));
			System.out.println(database.createConversation(3, 2, 1,""));
			System.out.println(database.createConversation(1, 2, 1,""));
			System.out.println(database.createConversation(2, 1, 1,""));
			System.out.println(database.createConversation(1, 3, 1,""));
			System.out.println(database.createConversation(3, 1, 1,""));
			System.out.println(database.sendText(1, 3, 1, "works", "sender_ip", "receiver ip"));
			ArrayList<TextMessage> try1 = database.fetchTextConversationHistory(1, 1);
			System.out.println(try1.size());
			for(TextMessage u : try1){
				System.out.print(u.getSenderid() + " ");
				System.out.println(u.getUsername());
				
			}
			
			// stmt.close();
			conn.close();
		} catch (SQLException se) {
			// Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			// Handle errors for Class.forName
			e.printStackTrace();
		} /*
			finally {
			// finally block used to close resources
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			}// nothin	g we can do
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}// end finally try
			
		}// end try*/
		
		Main main = new Main();
		Thread t = new Thread(main);
		t.start();
	}

	@Override
	public void run() {

		try {
			onlineUsers = new HashMap<Integer, ClientHandler>();
			@SuppressWarnings("resource")
			ServerSocket welcomeSocket = new ServerSocket(Constants.SERVERPORT);
			System.out.println("Server established. Waiting for Clients...");

			while (true) {
				try {
					// Create the Client Socket
					Socket clientSocket = welcomeSocket.accept();
					System.out.println("Socket Extablished...");
					// Create input and output streams to client
					ObjectOutputStream outToClient = new ObjectOutputStream(
							clientSocket.getOutputStream());
					ObjectInputStream inFromClient = new ObjectInputStream(
							clientSocket.getInputStream());

					// give information to a (parallel) handler
					ClientHandler processor = new ClientHandler(inFromClient,
							outToClient, welcomeSocket.getInetAddress()
									.getHostAddress(), database);
					Thread t = new Thread(processor);
					t.start();

				} catch (Exception e) {
					System.err.println("Server Error: " + e.getMessage());
					System.err.println("Localized: " + e.getLocalizedMessage());
					System.err.println("Stack Trace: " + e.getStackTrace());
					System.err.println("To String: " + e.toString());
					System.err.println("Stacktrace: ");
					e.printStackTrace();
				}

			}

		} catch (Exception e) {
			System.err.println("Could not create a server.");
			e.printStackTrace();
		}
	}

	public static HashMap<Integer, ClientHandler> getOnlineUsers() {
		return onlineUsers;
	}

	/**
	 * @return the database
	 */
	public static Database getDatabase() {
		try{
			database.setConnection(dataSource.getConnection());
			return database;
		}
		catch(SQLException se) {
			// Handle errors for JDBC
			se.printStackTrace();
			return null;
		}
	}

	/**
	 * @param database the database to set
	 */

}
