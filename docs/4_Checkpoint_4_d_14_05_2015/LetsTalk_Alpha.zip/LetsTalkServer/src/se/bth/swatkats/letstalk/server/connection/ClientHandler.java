package se.bth.swatkats.letstalk.server.connection;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.crypto.SealedObject;

import se.bth.swatkats.letstalk.Constants;
import se.bth.swatkats.letstalk.connection.encryption.CryptModule;
import se.bth.swatkats.letstalk.connection.packet.DatabaseQuery;
import se.bth.swatkats.letstalk.connection.packet.LoginMessage;
import se.bth.swatkats.letstalk.connection.packet.Packet;
import se.bth.swatkats.letstalk.connection.packet.internal.CloseConnectionMessage;
import se.bth.swatkats.letstalk.connection.packet.internal.OpenConnectionMessage;
import se.bth.swatkats.letstalk.connection.packet.message.Message;
import se.bth.swatkats.letstalk.connection.packet.message.TextMessage;
import se.bth.swatkats.letstalk.user.User;
import se.bth.swatkats.letstalk.user.UserFactory;

/**
 * This class is responsible for reacting on different kinds of Message Objects
 * on the server side
 * 
 * @author JS
 *
 */
public class ClientHandler implements Runnable {

	private User myUser;

	private ObjectInputStream in;

	private ObjectOutputStream out;

	private CryptModule crypto;

	private String serverip;
	
	private Database database;

	public ClientHandler(ObjectInputStream in, ObjectOutputStream out,
			String serverip, Database database) {
		this.in = in;
		this.out = out;
		this.serverip = serverip;
		this.database = database;
	}

	public User getMyUser() {
		return myUser;
	}

	private void setMyClient(User myClient) {
		this.myUser = myClient;
	}

	@Override
	public void run() {
		initConnection();
		while (true) {
			/* Create Message object and retrieve information */

			Packet message = receiveOnePacket();

			if (message instanceof CloseConnectionMessage) {
				sendToClient(message);
				System.out.printf("Client %s disconnected.\n", getMyUser()
						.getId());
				Main.getOnlineUsers().remove(getMyUser().getId());
				break;
			}
			processMessage(message);

		}
	}

	private void initConnection() {
		Packet message = null;
		try {
			message = (Packet) in.readObject();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (message instanceof OpenConnectionMessage) {
			OpenConnectionMessage m = (OpenConnectionMessage) message;
			crypto = new CryptModule();
			try {
				OpenConnectionMessage back = new OpenConnectionMessage(
						crypto.generateKeyPairFromClientKey(m.getKey()));
				out.writeObject(back);
			} catch (Exception e) {
				System.err.print("Key exchange failed.");
				e.printStackTrace();
			}

		} else {
			System.err.print("Need to initialize Connection first.");
		}
	}

	public void processMessage(Packet message) {
		if (message instanceof TextMessage) {
			TextMessage text = (TextMessage) message;
			System.out.printf("Received Text Message by %s for %s\n",
					text.getSenderid(), text.getReceiverid());
			System.out.println(text.getText());
			database.sendText(text.getReceiverid(), text.getSenderid(), text.getReceiverid(), text.getText(), text.getSenderip(), null);
			// TODO group chat support
			// forward to client
			sendMessageObject(message);

		} else if (message instanceof LoginMessage) {
			LoginMessage m = (LoginMessage) message;
			int id = Main.getDatabase().authenticateLogin(m.getUsername(),
					m.getPw());
			m.setReceiver(id);
			if (id > 0) {
				// register user as online
				if (Main.getOnlineUsers().containsKey(id)) {
					System.err.printf("User-id %d already online.", id);
				}
				Main.getOnlineUsers().put(id, this);
				setMyClient(new User());
				getMyUser().setId(id);
			}
			sendToClient(m);
		} else if (message instanceof DatabaseQuery) {
			executeDatabaseQuery((DatabaseQuery) message);
		} else {
			System.err.print("Error. Message type " + message.getClass()
					+ "not supported.");
		}
	}

	@SuppressWarnings("unchecked")
	private void executeDatabaseQuery(DatabaseQuery message) {
		Class<? extends Object>[] params = null;
		Method method = null;
		if (message.getParams() != null) {
			params = new Class[message.getParams().length];
			for (int i = 0; i < params.length; i++) {
				params[i] = message.getParams()[i].getClass();
			}
			Class<? extends Object> para = message.getParams().getClass();
		}
		try {
			method = Database.class.getMethod(message.getMethod(), params);
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}

		try {
			message.setResult(method.invoke(Main.getDatabase(), message.getParams()));
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		sendToClient(message);

	}

	/**
	 * This method is used to send to the connected client of this handler
	 * object.
	 * 
	 * @param message
	 *            the message to send
	 */
	public void sendToClient(Packet message) {
		message.setSenderip(serverip);
		if (message instanceof Message) {
			((Message) message).setSenderid(UserFactory.getClientById(
					Constants.SERVERID).getId());
		}
		forwardToClient(message);
	}

	/**
	 * This method is used to forward to the connected client of this handler
	 * object. Sender-id remains unchanged so it is usually used to forward
	 * messages from other clients.
	 * 
	 * @param message
	 *            the message to send
	 */
	public void forwardToClient(Packet message) {
		try {
			out.writeObject(crypto.encrypt(message));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void sendMessageObject(Packet message) {
		ClientHandler receiver = Main.getOnlineUsers().get(
				message.getReceiverid());
		if (receiver != null) {
			// client is online
			receiver.forwardToClient(message);
		} else {
			System.err.print("Client is offline or not existent.");
			// TODO client is offline or not existent
		}
	}

	private Packet receiveOnePacket() {
		SealedObject message = null;
		try {
			message = (SealedObject) in.readObject();
		} catch (ClassNotFoundException | IOException e) {

			e.printStackTrace();
		}
		try {
			return ((Packet) crypto.decrypt(message));
		} catch (Exception e) {
			System.err.print("Did not receive a packet.");
			return null;
		}
	}

}
