package se.bth.swatkats.letstalk.filedownload;
import java.io.File;  
import java.io.FileInputStream;  
import java.io.ObjectInputStream;  
import java.io.ObjectOutputStream;  
import java.net.ServerSocket;
import java.net.Socket;  
import java.util.Arrays; 

public class download extends Thread{
	private static final int PORT = 1995;  
    private static final int BUFFER_SIZE = 4096; 
    private long FILE_SIZE;
    private String path; 
    public void run() {  
        try {  
            ServerSocket serverSocket = new ServerSocket(PORT);  
            while (true) {  
                Socket s = serverSocket.accept();  
                filedownload(s);  
            }  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
    private void filedownload(Socket socket) throws Exception {  
         
        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());  
        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());  
  
        path=ois.readObject().toString();
        oos.writeLong(FILE_SIZE);
        File file = new File(path); 
        FileInputStream fis = new FileInputStream(file);  
        byte [] buffer = new byte[BUFFER_SIZE];  
        Integer bytesRead ;
        bytesRead = new Integer(fis.read(buffer));
        while (bytesRead.intValue() > 0) {  
            oos.writeObject(bytesRead);  
            oos.writeObject(Arrays.copyOf(buffer, buffer.length));  
        }  
  
        oos.close();  
        ois.close();  
        System.exit(0);      
    } 
    
    public static void main(String args[]) {  
        new download().start();  
    } 
}
