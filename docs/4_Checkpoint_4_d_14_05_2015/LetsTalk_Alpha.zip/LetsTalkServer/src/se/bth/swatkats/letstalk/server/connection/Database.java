package se.bth.swatkats.letstalk.server.connection;
import java.sql.*;

import se.bth.swatkats.letstalk.user.*;

import java.util.ArrayList;

import se.bth.swatkats.letstalk.connection.IDatabase;
import se.bth.swatkats.letstalk.connection.packet.message.FileMessage;
import se.bth.swatkats.letstalk.connection.packet.message.Message;
import se.bth.swatkats.letstalk.connection.packet.message.TextMessage;
import se.bth.swatkats.letstalk.gui.Conversation;

public class Database implements IDatabase{

	private Connection conn;

	/*
	* Creating a new instance requires a database connection.
	*/
	
	public Database(Connection conn) {
		this.conn = conn;
	}
	
	public void setConnection(Connection conn){
		this.conn = conn;
	}

	
	/**
	 * Authenticate login.
	 * @param username
	 * @param password
	 * @return user_id ,if authenticated;
	 * 			-1, if username exists but password is wrong;
	 * 			 0, if authentication didn't succeed;
	 * 			-2, if an SQL Exception caught.
	 */
	
	
	public int authenticateLogin(String username, String password) {
		String raw_query = "select pwd from users where username = ?";
		try {

			PreparedStatement stmt = conn.prepareStatement(raw_query);
			stmt.setString(1,username);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				if(rs.getString("pwd").equals(password)){
					raw_query = "select user_id from users where username = ? and pwd = ?";
					stmt = conn.prepareStatement(raw_query);
					stmt.setString(1,username);
					stmt.setString(2,password);
					rs = stmt.executeQuery();
					while(rs.next())
					{
						int user_id = rs.getInt("user_id");
						return user_id;
					}
				}
				else
					//username exists but wrong password
					return -1;
			}
			//If authentication did not succeed.
			return 0;

		} catch (SQLException e) {
			System.out.println(e);
			//something went wrong 
			return -2;
			
		}
	}
	
	/**
	 * Updates password.
	 * @param username
	 * @param newpwd new password
	 */
	
	// correct this
	public Integer changeUserPassword(Integer user_id, String username, String oldPass, String newPass){
		
		if(this.authenticateLogin(username, oldPass) <= 0)
			return -1;
		else{
			String raw_query = "update users set pwd = ? where user_id = ?";
			try {
				PreparedStatement stmt = conn.prepareStatement(raw_query,Statement.RETURN_GENERATED_KEYS);
				stmt.setString(1, newPass);
				stmt.setInt(2, user_id);
				stmt.executeUpdate();
				return 1;
			}
			catch (SQLException e) {
				System.out.println(e);
				return 0;
			}	
		}
		
	}

	/**
	 * Creates user
	 * @param username
	 * @param password
	 * @param email
	 * @param isAdmin
	 * @return 0, if an SQL Exception caught;
	 * 			-1 if username already exists;
	 */
	public Integer createUser(String username, String password, String email, Boolean isAdmin) {
		int admin_flag = 0;
		if (isAdmin)
			admin_flag = 1;
		String raw_query = "select * from users where username = ?";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query,Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1, username);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()){
				return -1;
			// username already exists
			}
		}
		catch (SQLException e) {
			System.out.println(e);
			return 0;
		}
		raw_query = "insert into users(user_id,username,pwd,email,admin_flag,status) values(null,?,?,?,?,0)";

		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query,Statement.RETURN_GENERATED_KEYS);
		
			stmt.setString(1, username);
			stmt.setString(2, password);
			stmt.setString(3, email);
			stmt.setInt(4, admin_flag);
		
			stmt.executeUpdate();
			ResultSet rs = stmt.getGeneratedKeys();
			if (rs.next()){
				return rs.getInt(1);
			}
		}
		catch (SQLException e) {
			System.out.println(e);
			return 0;
			//return null;
		}
		return 0;
	}


	public Boolean deleteUser(Integer user_id) {
		String raw_query = "delete from users where user_id = ?";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query);
			stmt.setInt(1,user_id);
			stmt.executeUpdate();
			return true;
		}
		catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
		
	}

	/**
	 * Adds a user to local address book
	 * @param user_current user_id of the current user
	 * @param user_to_add user_id of the user to be added
	 */
	public Boolean addLocalUser(Integer user_current, Integer user_to_add) {
		String raw_query = "insert ignore into address(user_id, user_id_has) values(?,?)";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query,Statement.RETURN_GENERATED_KEYS);
			stmt.setInt(1,user_current);
			stmt.setInt(2,user_to_add);
			stmt.executeUpdate();
			return true;
			
		}
		catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
	}
	
	/**
	 * Searches from global address book
	 * @param phrase search phrase
	 * @return Results as ResultSet
	 */
	public ArrayList<User> searchGlobalUsers(String phrase, Integer id){
		String raw_query = "select user_id, username , email, status, admin_flag from users where" + 
				" username like ? "  + 
				" and (? or user_id, user_id or ?) not in (select * from block_list);";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query);
			stmt.setString(1,"%" + phrase + "%");
			stmt.setInt(2, id);
			stmt.setInt(3, id);
			ResultSet rs = stmt.executeQuery();
			ArrayList<User> userlist = new ArrayList<User>() ;
			while (rs.next()) {
				int user_id = rs.getInt("user_id");
				String username = rs.getString("username");
				String email = rs.getString("email");
				int status = rs.getInt("status");
				int admin_flag = rs.getInt("admin_flag");
				userlist.add(new User(user_id,username,email,status,admin_flag));
			}
			return userlist;
		}
		catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
			return null;
		}
	}

	
	/**
	 * Searches user in local address book
	 * @param user_id
	 * @param phrase
	 * @return Results as ResultSet
	 */
	
	// correct this 
	public ArrayList<User> searchLocalUsers(Integer user_id, String phrase ) {
		String raw_query = "select A.user_id_has as id, U.username, U.email, U.status, U.admin_flag from users U, address A " + 
				" where " +					
				" A.user_id = ? and" + 
				" U.user_id = A.user_id_has and" +
				" U.username like ? " +
				" and (? or A.user_id, A.user_id or ?) not in (select * from block_list);";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query);
			stmt.setInt(1, user_id);
			stmt.setString(2,"%" + phrase + "%");
			stmt.setInt(3, user_id);
			stmt.setInt(4, user_id);
			ResultSet rs = stmt.executeQuery();
			ArrayList<User> userlist = new ArrayList<User>() ;
			while (rs.next()) {
				int id = rs.getInt("id");
				String username = rs.getString("username");
				String email = rs.getString("email");
				int status = rs.getInt("status");
				int admin_flag = rs.getInt("admin_flag");
				userlist.add(new User(id,username,email,status,admin_flag));
				System.out.print(user_id);
				System.out.print(" " + username);
				System.out.println(" " + email);
			}
			return userlist;
		}
		catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * Blocks the user
	 * @param user_id_by user_id of blocker
	 * @param user_id_to user_id of (to be) blocked
	 */
	
	// correct this
	public Boolean blockUserFromLocalBook(Integer user_id_by, Integer user_id_to){
		String raw_query = "insert ignore into block_list (user_id_by, user_id_to) values (?,?)";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query);
			stmt.setInt(1, user_id_by);
			stmt.setInt(2,user_id_to);
			stmt.executeUpdate();
			return true;
		}
		catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
	}
	
	
	
	/**
	 * Creates conversation between users
	 * @param user_one user_id of the first user
	 * @param user_two user_id of the second user
	 * @param chat_type
	 * @return
	 */
	public Integer createConversation(Integer user_one, Integer user_two, Integer chat_type, String g_name ){
		String raw_query = "insert into conversations" +
					" (conv_id,user_one, user_two, chat_type,time_of_update,time_user_one, time_user_two, status)"+
					" select NULL,?,?,?,NULL, NULL, NULL, NULL from DUAL  "+
					" where not ( " + 
					"exists ( " + 
					" select * from conversations C " +
					" where " +
					" case " +  
					" when " + 
					" C.chat_type = 1 " + 
					" then " +
					" ( C.user_one= ? and C.user_two=? ) " + 
					" or " +
					" ( C.user_one=? and C.user_two=? ) " + 
					" end )" +
					" or exists ( " +
					" select * from block_list where user_id_by =  ? or ?  and user_id_to =  ? or ? )" +
					"); ";	
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query,Statement.RETURN_GENERATED_KEYS);
			stmt.setInt(1, user_one);
			stmt.setInt(2, user_two);
			stmt.setInt(3, chat_type);
			stmt.setInt(4, user_one);
			stmt.setInt(5, user_two);
			stmt.setInt(6, user_two);
			stmt.setInt(7, user_one);
			stmt.setInt(8, user_two);
			stmt.setInt(9, user_one);
			stmt.setInt(10, user_two);
			stmt.setInt(11, user_one);
			stmt.executeUpdate();
			ResultSet rs = stmt.getGeneratedKeys();
			if (rs.next()){
				return rs.getInt(1);
			}
			return 0;
		}
		catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
			return -1;
		}
	}
	
	public Integer insertText(String text){
		String raw_query = "insert into text_msg values (null, ?)";
		try{
			PreparedStatement stmt = conn.prepareStatement(raw_query,Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1,text);
			stmt.executeUpdate();
			ResultSet rs = stmt.getGeneratedKeys();
			if (rs.next()){
				return rs.getInt(1);
			}
			return 0;
		}
		catch (SQLException e) {
			System.out.println(e);
			return 0;
		}
	}	
	
	public int sendText(int conv_id, int user_id_s, int user_id_r, String text, String user_s_ip, String user_r_ip) {
		
		
		int text_id = this.insertText(text);
		Timestamp time = null;
		int conv_msg_id=0;
		String raw_query = "insert into conv_msg values(null,?,?,?,?,0,'text',null,?,?)";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query,Statement.RETURN_GENERATED_KEYS);
			stmt.setInt(1,conv_id);
			stmt.setInt(2,user_id_s);
			stmt.setInt(3,user_id_r);
			stmt.setInt(4,text_id);
			stmt.setString(5,user_s_ip);
			stmt.setString(6,user_r_ip);

			stmt.executeUpdate();
			ResultSet rs = stmt.getGeneratedKeys();
			if (rs.next()){
				 conv_msg_id = rs.getInt(1);
			}
			
		} catch (SQLException e) {
			System.out.println(e);
			return 0;
		}
		raw_query = "select time from conv_msg where conv_msg_id = ?";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query);
			stmt.setInt(1,conv_msg_id);
			
			ResultSet rs = stmt.executeQuery();
			
			if (rs.next()){
				 time = rs.getTimestamp("time");
			}
			
		} catch (SQLException e) {
			System.out.println(e);
			return 0;
		}
		raw_query = "update conversations set time_of_update = ? where conv_id = ?";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query);
			stmt.setTimestamp(1,time);
			stmt.setInt(2,conv_msg_id);
			
			stmt.executeUpdate();
			return 1;
			
		} catch (SQLException e) {
			System.out.println(e);
			return 0;
		}
	}
	public Integer sendFile(int conv_id, int user_id_s, int user_id_r, String filename, String user_s_ip, String user_r_ip) {
		
		int file_id = this.insertFile(filename);
		int conv_msg_id=0;
		Timestamp time = null;
		String raw_query = "insert into conv_msg values(null,?,?,?,null,?,'file',null,?,?)";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query,Statement.RETURN_GENERATED_KEYS);
			stmt.setInt(1,conv_id);
			stmt.setInt(2,user_id_s);
			stmt.setInt(3,user_id_r);
			stmt.setInt(4,file_id);
			stmt.setString(5,user_s_ip);
			stmt.setString(6,user_r_ip);

			stmt.executeUpdate();
			ResultSet rs = stmt.getGeneratedKeys();
			if (rs.next()){
				 conv_msg_id = rs.getInt(1);
				 return 1;
			}
			
		} catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
			return 0;
		}
		raw_query = "select time from conv_msg where conv_msg_id = ?";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query);
			stmt.setInt(1,conv_msg_id);
			
			ResultSet rs = stmt.executeQuery();
			
			if (rs.next()){
				 time = rs.getTimestamp("time");
			}
			
		} catch (SQLException e) {
			System.out.println(e);
			return 0;
		}
		raw_query = "update conversations set time_of_update = ? where conv_id = ?";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query);
			stmt.setTimestamp(1,time);
			stmt.setInt(2,conv_msg_id);
			
			
			stmt.executeUpdate();
			return 1;
			
		} catch (SQLException e) {
			System.out.println(e);
			return 0;
		}
	}


	/*
	* messageType is 0 for text; 1 for files
	* message_id is either text_id or file_id
	* Returns 1 if successful.
	*/
	
	public ArrayList<Conversation> fetchConversationsForUser(Integer user_id){
		String raw_query = " ( " +
					"select C.conv_id, C.time_of_update, U.username as convname " +
					"from conversations C , users U " + 
					"where " + 
					" case " +
					" when C.user_one = ? then U.user_id = C.user_two " +
					" when C.user_two = ? then U.user_id = C.user_one " +
					" end " +
					" and " + 
					" C.user_one = ? or C.user_two =?  " +
					"and (C.user_one or C.user_two, C.user_two or C.user_one) not in (select * from block_list)" +
					") "+ 
					"union " +
					"( " +
					" select C.conv_id, C.time_of_update , G.g_name as convname " +
					" from conversations C, group_users G " +
					" where " + 
					" G.user_id = ? " +
					" and " + 
					" G.conv_id = C.conv_id "+
					" ) "+
					" order by time_of_update desc ; ";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query);
			stmt.setInt(1,user_id);
			stmt.setInt(2,user_id);
			stmt.setInt(3,user_id);
			stmt.setInt(4,user_id);
			stmt.setInt(5,user_id);
			
			ResultSet rs = stmt.executeQuery();
			ArrayList<Conversation> convlist = new ArrayList<Conversation>();
			while (rs.next()){
				int x = rs.getInt("conv_id");
				Timestamp time = rs.getTimestamp("time_of_update");
				String convname = rs.getString("convname");
				convlist.add(new Conversation(x, convname, time));
				System.out.print (x);
				System.out.println(time);
				System.out.println(convname);
				
			}
			return convlist;
		} catch (SQLException e) {
			System.out.println(e);
			return null;
		}
	}

	@Override
	public Boolean setUserStatusAvailable(Integer userid) {
		String raw_query = "update users set status = 0 where user_id = ?";
		try {
				PreparedStatement stmt = conn.prepareStatement(raw_query);
				stmt.setInt(1,userid);
				stmt.executeUpdate();
				return true;				
			}
		catch (SQLException e) {
			System.out.println(e);
			return false;
		}
	}

	@Override
	public Boolean setUserStatusBusy(Integer userid) {
		String raw_query = "update users set status = 2 where user_id = ?";
		try {
				PreparedStatement stmt = conn.prepareStatement(raw_query);
				stmt.setInt(1,userid);
				stmt.executeUpdate();
				return true;				
			}
		catch (SQLException e) {
			System.out.println(e);
			return false;
		}
	}



	public Boolean unblockUserFromLocalBook(Integer user_id_by, Integer user_id_to) {
		String raw_query = "delete from block_list where user_id_by = ?" + 
				" and  user_id_to = ? ; ";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query);
			stmt.setInt(1, user_id_by);
			stmt.setInt(2,user_id_to);
			stmt.executeUpdate();
			return true;
		}
		catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
	}

	/*
	 * @param: conv_id
	 * @param: user_id id of the user whose is requesting the conversation
	 * returns the sorted text conversations <TextMessage>
	 */
	@Override
	public ArrayList<TextMessage> fetchTextConversationHistory(Integer conversationId, Integer user_id) {
		
		String raw_query = " select R.conv_msg_id, R.time, " + 
				" T.text_msg, " +
				" U.username, U.user_id, " + 
				" R.user_id_r as rec from " +
				" conv_msg R , users U , text_msg T  " +
				" where " +
				" U.user_id = ?"+
				" and R.user_id_s = U.user_id or R.user_id_r = U.user_id " +
				" and " + 
				" R.conv_id = ? " +
				" and R.text_id = T.text_id "+
				" and R.msg_type = 'text' " +
				" order by R.conv_msg_id desc ";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query);
			stmt.setInt(1,user_id);
			stmt.setInt(2,conversationId);
			
			ResultSet rs = stmt.executeQuery();
			ArrayList<TextMessage> convlist = new ArrayList<TextMessage>();
			while (rs.next()){
				int x = rs.getInt("conv_msg_id");
				Timestamp time = rs.getTimestamp("time");
				String text = rs.getString("text_msg");
				String username = rs.getString("username");
				int senderid = rs.getInt("user_id");
				int rec = rs.getInt("rec");
				convlist.add(new TextMessage(senderid,username,text,time,rec));
			}
			return convlist;
		} catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
			return null;
		}
	}

	/*
	 * @param: conv_id
	 * @param: user_id id of the user whose is requesting the conversation
	 * returns the sorted file conversations <FileMessage>
	 */
	@Override
	public ArrayList<FileMessage> fetchFileConversationHistory(Integer conversationId, Integer user_id) {
		String raw_query = " select R.conv_msg_id, R.time, " + 
				" F.filename, F.file_id " +
				" U.username, U.user_id, " + 
				" if(U.user_id = R.user_id_r, R.user_id_s, R.user_id_r) as rec from " +
				" conv_msg R , users U , files F  " +
				" where " +
				" U.user_id = ?"+
				" and R.user_id_s = U.user_id or R.user_id_r = U.user_id " +
				" and " + 
				" R.file_id = F.file_id " +
				" and R.conv_id = ? " +
				" and R.msg_type = 'file' " +
				" order by R.conv_msg_id desc ";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query);
			stmt.setInt(1,user_id);
			stmt.setInt(2,conversationId);
			
			ResultSet rs = stmt.executeQuery();
			ArrayList<FileMessage> convlist = new ArrayList<FileMessage>();
			while (rs.next()){
				int x = rs.getInt("conv_msg_id");
				Timestamp time = rs.getTimestamp("time");
				String filename = rs.getString("filename");
				int file_id = rs.getInt("file_id");
				String username = rs.getString("username");
				int senderid = rs.getInt("user_id");
				int rec = rs.getInt("rec");
				convlist.add(new FileMessage (senderid,username,filename,file_id ,time, rec));
			}
			return convlist;
		} catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public Boolean deleteUserFromLocalBook(Integer user_current, Integer user_to_add) {
		String raw_query = "delete from address where user_id = ? and user_id_has = ? ";
		try {
			PreparedStatement stmt = conn.prepareStatement(raw_query,Statement.RETURN_GENERATED_KEYS);
			stmt.setInt(1,user_current);
			stmt.setInt(2,user_to_add);
			stmt.executeUpdate();
			return true;
			
		}
		catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
			return false;
		}
	}

	/*
	 * makes an entry in the database for the given filename and generates a unique id
	 * 
	 *return the id to be used as filename for storing the file on server
	 */
	public int insertFile(String filename){
		
		String raw_query = "insert into files values (null, ?)";
		try{
			PreparedStatement stmt = conn.prepareStatement(raw_query,Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1,filename);
			stmt.executeUpdate();
			ResultSet rs = stmt.getGeneratedKeys();
			if (rs.next()){
				return rs.getInt(1);
			}
			return 0;
		}
		catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
			return -1;
		}
	}

}
